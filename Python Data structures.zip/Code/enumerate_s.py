lst= [10, 20, 30, 40, 50]
t = (100,700), 200, 300, 400, 500
d = {"A": 4, "B": 18, "C": 0, "D": 3}
s = {1000, 2000, 3000, 4000, 5000}
# print(lst)
# print(t)
# print(d)
# print(s)

for i in enumerate(d):
    print(i[0] , d[i[1]])
